public class math {

    public static void main(String[] args) {

        System.out.println("5 + 4 = " + (5 + 4)); 
        System.out.println("5 - 4 = " + (5 - 4)); 
        System.out.println("5 * 4 = " + (5 * 4)); 
        System.out.println("5 % 4 = " + (5 / 4)); // integer division! 
        
        // Use this if we want to print floats 
        System.out.println("5 / 4 = " + (5.0 / 4.0)); 

        // random number between (0, 1) 
        System.out.println(Math.random()); 
        // Can conver this into int and scale it to get random integer 
        System.out.println((int)(15 * Math.random()));  

        System.out.println(4097 / 1024);

    }
    
}
